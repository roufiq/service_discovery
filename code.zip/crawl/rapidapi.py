from gql import gql, Client, AIOHTTPTransport
from pprint import pprint
import json
import requests
import pymysql

# configure database
from gql.transport.exceptions import TransportQueryError

conn = pymysql.connect(host='localhost', user='root', passwd='',db='rapidapi')
cur = conn.cursor();
cur.execute("SELECT * from provider")

# Select your transport with a defined url endpoint
url="https://rapidapi.com/_gateway/graphql"
transport = AIOHTTPTransport(url=url)

# Create a GraphQL client using the defined transport
client = Client(transport=transport, fetch_schema_from_transport=True)

# Provide a GraphQL query
paramCategory = {"searchArguments": {"sortBy": "installsAllTime", "size": 1, "offset":0, "page": 1, "categoryName":"Data"}}
query_list_script = """
    query SearchByCategory($searchArguments: SearchArguments) {
    apiSearch(searchArguments: $searchArguments) {
        results {
            id
            name
            title
            thumbnail
            key
            description
            categoryName
            User {
                id
                username
            }
            score {
                avgLatency
                avgSuccessRate
                popularityScore
            }
            slugifiedName
            

            }
        }
    }
"""
query_list = gql(
query_list_script
)

# Execute the query on the transport


query_category_script="""
query Categories($orderByField: String, $orderDirection:OrderDirection) 
{categories(orderByField:$orderByField, orderDirection:$orderDirection) 
{rank name}}
"""

query_category= gql(query_category_script)
params_category={"orderByField": "rank", "orderDirection": "asc"}
categories= client.execute(query_category, variable_values=params_category)['categories']

# Check total for Category

queryTotalPerCategory=gql(
    """
    query SearchByCategory($searchArguments: SearchArguments) {
    apiSearch(searchArguments: $searchArguments) {
        total
    }
}
    """
)
def store(provider):
    cur.execute("INSERT IGNORE INTO provider (id, name , title, thumbnail, api_key, "
                "description, categoryName, slugifiedName, ownerName, avgLatency, avgSuccessRate, popularityScore) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (provider[0]['id'],provider[0]['name'], provider[0]['title'], provider[0]['thumbnail'], provider[0]['key'],
                 (provider[0]['description']).encode('utf-8'), provider[0]['categoryName'],provider[0]['slugifiedName'], provider[0]['User']['username'],
                 provider[0]['score']['avgLatency'], provider[0]['score']['avgSuccessRate'], provider[0]['score']['popularityScore']))
    cur.connection.commit()
# pprint(total)

for c in range(len(categories)):
    try:
        print(categories)
        categoryName = categories[c]['name']
        # categoryName = categories[c]['name']

        print(categoryName)
        params_total = {"searchArguments": {"sortBy": "installsAllTime", "size": 1, "offset": 0, "page": 1,
                                            "categoryName": categoryName}}
        total = client.execute(queryTotalPerCategory, variable_values=params_total)['apiSearch']['total']
        print("total: " + str(total))

        offset = 0
        for t in range(total):
            try:
                offset = t
                params = {
                    "searchArguments": {"sortBy": "installsAllTime", "size": 1, "offset": offset, "page": (offset + 1),
                                        "categoryName": categoryName}}
                provider = client.execute(query_list, variable_values=params)['apiSearch']['results']
                # json_object = json.dumps(provider, indent=4)
                # pprint(json_object)
                # pro= json.loads(json_object)
                if (provider[0]['score'] == None):
                    provider[0]['score'] = {}
                    provider[0]['score']['avgLatency'] = None
                    provider[0]['score']['avgSuccessRate'] = None
                    provider[0]['score']['popularityScore'] = None

                # pprint(provider)
                store(provider)
                print(categoryName + "," + "offset: " + str(offset) + ", " + provider[0]['slugifiedName'] + "," +
                      provider[0]['User']['username'])
            except TransportQueryError :
                pass
    except TransportQueryError :
        pass

# Nanti bisa saja error handling api not found




# result = client.execute(query, variable_values=params)['apiSearch']['results']
# pprint(result)






paramDetails={"slugifiedName": "skyscanner-flight-search", "ownerName": "skyscanner"}

# detail = client.execute(queryDetail,variable_values=paramDetails)
# pprint(detail)
