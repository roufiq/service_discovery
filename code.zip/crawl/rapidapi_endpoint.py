from gql import gql, Client, AIOHTTPTransport
from pprint import pprint
import pymysql
import json
import re

# configure DB
from gql.transport.exceptions import TransportError, TransportQueryError
from pymysql import Error, OperationalError

# Initiate Query Script
queryDetail= gql(
    """
    query ApiBySlugifiedNameAndOwnerName($slugifiedName: String, $ownerName: String) {
    apiBySlugifiedNameAndOwnerName(slugifiedName: $slugifiedName, ownerName: $ownerName) {
        id
        official
        proxy
        version {
            id
            api
            current
            description
            longDescription
            name
            status
            pricing
            thumbnail
            keywords
            visibility
            websiteUrl
            authentication {
                id
                authType
                description
                accessTokenUrl
                separator
                authorizationUrl
                oauthTokenUrl
                requestTokenUrl
                grantType
                clientAuthentication
                authParams {
                    id
                    status
                    name
                    description
                }
            }
            payloads(pagingArgs: {
                limit: -1
            }) {
                id
                name
                format
                body
                headers
                description
                type
                status
                statusCode
                apiendpoint
                examples
                schema
            }
            terms {
                id
                name
                text
                apiversion
                status
                createdAt
                updatedAt
            }
            publicdns {
                address
            }
            groups {
                id
                name
                description
                summary
            }
            endpoints(pagingArgs: {
                limit: -1
            }) {
                apiversion
                id
                group
                method
                name
                route
                response
                payload
                code
                description
                displayResponse
                endpointPath {
                    summary
                    description
                    path
                }
                externalDocs {
                    description
                    url
                }
                graphQLSchema {
                    id
                    schema
                    status
                    allowMarketplaceSchemaRefresh
                    endpoint
                }
                params {
                    parameters
                }
            }
        }
    }
}
    """
)

url="https://rapidapi.com/_gateway/graphql"
transport = AIOHTTPTransport(url=url)
client = Client(transport=transport, fetch_schema_from_transport=True)

conn = pymysql.connect(host='localhost', user='root', passwd='', db='rapidapi')
cursor = conn.cursor()
# cursor.execute("SELECT id, slugifiedName, ownerName from provider ORDER BY id LIMIT 5000 OFFSET 0")

# Handling records to ensure check service provider who doesn't have endpoint API
# cursor.execute("SELECT id, slugifiedName, ownerName FROM provider WHERE id NOT IN (SELECT DISTINCT provider_id FROM endpoint) ORDER BY id LIMIT 5000 OFFSET 0")

# Handling error to check payload response missing from endpoint
cursor.execute("SELECT id, slugifiedName, ownerName FROM provider "
               "WHERE id IN  "
               "    (SELECT provider_id FROM endpoint "
               "        WHERE response_id NOT IN  "
               "            (SELECT id  FROM endpoint_response	) AND (response_id IS NOT NULL AND response_id !='')) "
               "ORDER BY id LIMIT 1000 OFFSET 5")


def store_params(parameter):
    cur= conn.cursor()
    cur.execute("INSERT IGNORE INTO parameters (endpoint_id, id, param_condition, name, description,"
                "paramType, querystring, status, parameter_type, parameter_value)"
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (parameter['endpoint'], parameter['id'], parameter['condition'], parameter['name'],
                 parameter['description'], parameter['paramType'], parameter['querystring'],
                 parameter['status'], parameter['type'], parameter['value']))
    cur.connection.commit()
    print("insert params ok")

def store_response(payload):
    cur = conn.cursor()
    cur.execute("INSERT IGNORE INTO endpoint_response (id, name, format, body, headers,description,"
                "statusCode, apiendpoint, examples, response_schema)"
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (payload['id'], payload['name'], payload['format'],payload['body'], payload['headers'],
                 payload['description'], payload['statusCode'], payload['apiendpoint'], payload['examples'], payload['schema']))
    cur.connection.commit()
    print("insert response ok")
    # cur.close()

def store_authentication(apiversion, authentication):
    cur = conn.cursor()
    cur.execute("INSERT IGNORE INTO authentication_api (id, apiversion, authType, description, accessTokenUrl, auth_separator, authorizationUrl,"
                "oauthTokenUrl, requestTokenUrl, grantType, clientAuthentication, authParams)"
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (authentication['id'], apiversion, authentication['authType'], authentication['description'], authentication['accessTokenUrl'],
                 authentication['separator'], authentication['authorizationUrl'],authentication['oauthTokenUrl'], authentication['requestTokenUrl'],
                 authentication['grantType'], authentication['clientAuthentication'], authentication['authParams']))
    cur.connection.commit()
    print("insert auth ok")
    # cur.close()

def store_endpoint(params,  endpoint):
    cur = conn.cursor()
    cur.execute("INSERT IGNORE INTO endpoint (id, apiversion, provider_id, official,version_name,"
                "endpoint_name, method, route, response_id, payload, code, description, api_keywords, websiteUrl,"
                " publicdns_address, group_name)"
                "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                (endpoint['id'], endpoint['apiversion'], params['provider_id'], params['official'],
                 params['version_name'], endpoint['name'], endpoint['method'],
                 endpoint['route'], endpoint['response'],endpoint['payload'],endpoint['code'],endpoint['description'],
                 params['keywords'], params['websiteUrl'],params['publicdns_address'],params['group']))
    cur.connection.commit()
    print("insert endpoint ok")
    # cur.close()

try:

    records = cursor.fetchall()
    print("total row ", cursor.rowcount)

# For Every Record in DB query Endpoint API based on slugifiedName & ownerName
    i=0
    for row in records:
        print(i)
        slugifiedName = row[1]
        ownerName = row[2]
        param_name= {"slugifiedName": slugifiedName, "ownerName": ownerName}
        print(param_name)
        try:
            api = client.execute(queryDetail, variable_values=param_name)['apiBySlugifiedNameAndOwnerName']
            # pprint(param_name)
            params={}
            params['provider_id']=row[0]
            params['official']=api['official']
            # try:
            params['version_name'] = api['version']['name']
            # except TypeError as e:
            #     continue
            keywords= api['version']['keywords']
            if(keywords!=None and len(keywords)>0):
                params['keywords']= ",".join(keywords)
            params.setdefault('keywords', None)
            params['websiteUrl']= api['version']['websiteUrl']
            params['publicdns_address']= api['version']['publicdns'][0]['address']
            groups= api['version']['groups']
            group=None
            endpoints= api['version']['endpoints']
            print("endpoint length, " + str(len(endpoints)))

            if api['version']['authentication']!=None:
                auth= api['version']['authentication']
                auth.setdefault('authType',None)
                auth.setdefault('description',None)
                auth.setdefault('accessTokenUrl',None)
                auth.setdefault('separator',None)
                auth.setdefault('authorizationUrl',None)
                auth.setdefault('oauthTokenUrl',None)
                auth.setdefault('requestTokenUrl',None)
                auth.setdefault('grantType',None)
                auth.setdefault('clientAuthentication',None)
                auth.setdefault('authParams',None)
                # print(len(auth['authParams']))
                if(auth['authParams']!=None):
                    authParams = json.dumps(auth['authParams'])
                    auth['authParams'] = authParams
                # print(auth)
                store_authentication(api['version']['id'], auth)
            # parameters= api['version']['endpoints']['params']['parameters']
            # for parameter in parameters:
            #     store_params(parameter)
            payloads= api['version']['payloads']
            print("length payloads "+str(len(payloads)))
            for payload in payloads:
                print(payload)
                # pprint(payload)
                if (payload['body']!=None):
                    json_body = json.dumps(payload['body'],ensure_ascii=True) \
                        .replace("'", "''") \
                        .replace('\\', '\\\\')
                    payload['body'] = json_body
                if(payload['headers']!=None):
                    json_headers = json.dumps(payload['headers'],ensure_ascii=True) \
                        .replace("'", "''") \
                        .replace('\\', '\\\\')
                    payload['headers'] = json_headers
                if(payload['schema']!=None):
                    json_schema = json.dumps(payload['schema'],ensure_ascii=True) \
                        .replace("'", "''") \
                        .replace('\\', '\\\\')
                    # print(json_schema)
                    payload['schema'] = json_schema
                if(payload['examples']!=None):
                    json_examples = json.dumps(payload['examples'],ensure_ascii=True) \
                        .replace("'", "''") \
                        .replace('\\', '\\\\')
                    payload['examples'] = json_examples
                # print(payload)
                store_response(payload)

            for endpoint in endpoints:
                params.setdefault('group', None)
                endpoint.setdefault('group', None)
                if((len(groups)>0) and (endpoint['group']!=None)):
                    group = next((sub for sub in groups if sub['id'] == endpoint['group']), None)
                    if(group != None):
                        params['group'] = group['name']
                params.setdefault('keywords',None)
                # print(params)
                # print(endpoint)
                store_endpoint(params, endpoint)
                parameters= []
                number_params= endpoint['params']
                if(number_params!=None):
                    parameters=number_params['parameters']
                    for parameter in parameters:

                        parameter.setdefault('paramType', None)
                        parameter.setdefault('querystring', None)
                        parameter.setdefault('value', None)
                        if(parameter['value']!=None):
                            value= json.dumps(parameter['value'])
                            parameter['value']=value
                        parameter.setdefault('type', None)
                        parameter.setdefault('description', None)
                        # pprint(parameter)
                        store_params(parameter)
            i+=1

            # Store The Data

# Handling Error if API page not found
        except TransportQueryError:
            i += 1
            pass
        except OperationalError:
            i += 1
            pass
except Error as e:
    pprint("DB error ", e)

finally:
    if (conn.open):
        conn.close()
        cursor.close()
        print("MySQL connection is closed")



