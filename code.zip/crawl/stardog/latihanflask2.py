import xml.etree.ElementTree as ET
import re
from flask import Flask, request, render_template, send_file, Response, jsonify
import matplotlib.pyplot as plt
from io import BytesIO
import networkx as nx
import werkzeug
werkzeug.cached_property = werkzeug.utils.cached_property
from flask_restx import Api, Resource, reqparse
import pandas as pd
import ast
import os
from werkzeug.datastructures import FileStorage

app = Flask(__name__)
api = Api(app)

upload_parser = api.parser()
upload_parser.add_argument('file',
                           location='files',
                           type=FileStorage)
listroot=[]
listchild=[]

def perf_func(elem, func, level=0, root = None):
    func(elem,level,root)
    root = re.sub('{.*?}', '', str(elem.tag))
    for child in list(elem):
        tag = re.sub('{.*?}', '', str(child.tag))
        perf_func(child, func, level+1, root)

def print_level(elem,level,root):
    tag = re.sub('{.*?}', '', str(elem.tag))
    if level is 0:
        pass
    else:
        listroot.append(root)
        listchild.append(tag)


@api.route('/bpel/')
@api.expect(upload_parser)
class BPEL(Resource):
    def post(self):
        args = upload_parser.parse_args()
        file = args.get('file')
        root = ET.parse(file)
        perf_func(root.getroot(), print_level)
        G = nx.Graph()
        for u, v in zip(listroot, listchild):
            G.add_edge(u, v)
        plt.title("File "+file.filename+" node")
        nx.draw_networkx(G)
        img = BytesIO()  # file-like object for the image
        plt.savefig(img)  # save the image to the stream
        img.seek(0)  # writing moved the cursor to the end of the file, reset
        plt.clf()  # clear pyplot

        return send_file(img, mimetype='image/png')
        # return jsonify(
        #     print(G.edges(data=False))
        # )


@api.route('/discovery/')
@api.expect(upload_parser)
class Discovery(Resource):
    def post(self):
        args = upload_parser.parse_args()
        file = args.get('file')
        root = ET.parse(file)
        perf_func(root.getroot(), print_level)
        G = nx.Graph()
        for u, v in zip(listroot, listchild):
            G.add_edge(u, v)
        plt.title("File "+file.filename+" node")
        nx.draw_networkx(G)
        img = BytesIO()  # file-like object for the image
        plt.savefig(img)  # save the image to the stream
        img.seek(0)  # writing moved the cursor to the end of the file, reset
        plt.clf()  # clear pyplot

        return send_file(img, mimetype='image/png')
        # return jsonify(
        #     print(G.edges(data=False))
        # )
@api.route('/query/')
class DiscoveryQuery(Resource):
    def get(self):
        data = pd.read_csv('users.csv')  # read local CSV
        data = data.to_dict()  # convert dataframe to dict
        return {'data': data}, 200  # return data and 200 OK

    def post(self):
        parser = reqparse.RequestParser()  # initialize
        parser.add_argument('userId', required=True)  # add args
        parser.add_argument('name', required=True)
        parser.add_argument('city', required=True)
        args = parser.parse_args()  # parse arguments to dictionary

        # read our CSV
        data = pd.read_csv('users.csv')

        if args['userId'] in list(data['userId']):
            return {
                       'message': args['userId']+" already exists."
                   }, 409
        else:
            # create new dataframe containing new values
            new_data = pd.DataFrame({
                'userId': [args['userId']],
                'name': [args['name']],
                'city': [args['city']],
                'locations': [[]]
            })
            # add the newly provided values
            data = data.append(new_data, ignore_index=True)
            data.to_csv('users.csv', index=False)  # save back to CSV
            return {'data': data.to_dict()}, 200  # return data with 200 OK

    def put(self):
        parser = reqparse.RequestParser()  # initialize
        parser.add_argument('userId', required=True)  # add args
        parser.add_argument('location', required=True)
        args = parser.parse_args()  # parse arguments to dictionary

        # read our CSV
        data = pd.read_csv('users.csv')

        if args['userId'] in list(data['userId']):
            # evaluate strings of lists to lists !!! never put something like this in prod
            data['locations'] = data['locations'].apply(
                lambda x: ast.literal_eval(x)
            )
            # select our user
            user_data = data[data['userId'] == args['userId']]

            # update user's locations
            user_data['locations'] = user_data['locations'].values[0] \
                .append(args['location'])

            # save back to CSV
            data.to_csv('users.csv', index=False)
            # return data and 200 OK
            return {'data': data.to_dict()}, 200

        else:
            # otherwise the userId does not exist
            return {
                       'message': args['userId']+" user not found."
                   }, 404

    def delete(self):
        parser = reqparse.RequestParser()  # initialize
        parser.add_argument('userId', required=True)  # add userId arg
        args = parser.parse_args()  # parse arguments to dictionary

        # read our CSV
        data = pd.read_csv('users.csv')

        if args['userId'] in list(data['userId']):
            # remove data entry matching given userId
            data = data[data['userId'] != args['userId']]

            # save back to CSV
            data.to_csv('users.csv', index=False)
            # return data and 200 OK
            return {'data': data.to_dict()}, 200
        else:
            # otherwise we return 404 because userId does not exist
            return {
                       'message': args['userId']+" user not found."
                   }, 404



if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)