# import json
import os
# import requests

no_file=0
uploadUrl= "https://converter.swagger.io/api/convert"


for root, dirs, files in os.walk("D:\Download Program\APIs", topdown=False):

    for name in files:
        if name == "swagger.json" or name=="openapi.json":
            no_file+=1
            found = os.path.join(root, name)
            os.remove(found)
            print("removed")
