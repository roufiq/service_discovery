import json
import os
import jsonpath_rw_ext as jp
import  uuid


no_file=0
list_key = {}
list_key['schemas'] = 0
list_key['responses'] = 0
list_key['parameters'] = 0
list_key['examples'] = 0
list_key['requestBodies'] = 0
list_key['headers'] = 0
list_key['securitySchemes'] = 0
list_key['links'] = 0
list_key['callbacks'] = 0
for root, dirs, files in os.walk("C:/Users/Asus/OneDrive/Documents/Tugas Kuliah/Semester 3/Tesis/OAS/openapi-directory-master", topdown=False):

    for name in files:
        if name == "openapi.json":
            no_file+=1
            found = os.path.join(root, name)
            print(found)
#             load JSON file
            with open(found) as f:
                document=json.load(f)
                component_keys={}
                component_keys['id']=str(uuid.uuid4())
                component_keys=jp.match('$.components[*]', document)

                # print(component_keys)
                for comp in component_keys:
                    # list_key=list(comp.keys())
                    # print(list_key)
                    parameters = comp.get('parameters')
                    print(parameters)

#                 if(component_keys):
#                     for key, value in component_keys[0].items():
#                         # print(key)
#                         list_key[key]+=1
#                         print(list_key)
#
#                         # list_key[key]+=1
#
# print(list_key)