import json
import os
import requests
import yaml
import datetime
import shutil
from pprint import pprint
from json import JSONEncoder

no_file=0
uploadUrl= "https://converter.swagger.io/api/convert"

def defaultconverter(o):
  if isinstance(o, datetime.datetime):
      return o.__str__()

def default(obj):
    if isinstance(obj, (datetime.date, datetime.datetime)):
        return obj.isoformat()

string = "bcdefghijklmnopqrstuvwxyz"
error_folder = r"D:/Download Program/error/"
base = r"D:/Download Program/APIs/"
for i, v in enumerate(string):
    for root, dirs, files in os.walk(base+v, topdown=False):

        for name in files:
            if name == "openapi.yaml":
                no_file += 1
                found = os.path.join(root, name)
                print(found)

                url = "https://converter.swagger.io/api/convert"
                headers = {
                    "Content-Type": "application/binary"

                }
                with open(found, 'rb') as f:
                    document = yaml.load(f)
                    res = requests.post(url='https://converter.swagger.io/api/convert',
                                        json=document,
                                        headers={'Content-Type': 'application/json'})
                    data = str(res.text)

                    # json_output = json.loads(data)
                    file_json = open(os.path.join(root, 'openapi.json'), 'w+')
                    json_dumps=json.dumps(data, indent=4, default=default)
                    file_json.write(json_dumps)
                    file_json.close()






