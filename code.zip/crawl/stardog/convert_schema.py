import json
import os
import jsonpath_rw_ext as jp
import pymysql
import uuid
import six
import pipes


replace={"[":"", "]":"", "\"":"", " ":""}
def replace_all(text, dic):
    for i, j in dic.items():
        text = text.replace(i, j)
    return text

def store_schemas(schema):
    cur.execute("UPDATE schemas_object SET (minLength=%s, maxLength=%s, minItems=%s, maxItems=%s, minimum=%s, maximum=%s, minProperties=%s, maxProperties=%s)"
                "WHERE id_service=%s",
                (schema['minLength'],['maxLength'],['minItems'],['maxItems'],['minimum'],['maximum'],['minProperties'],['maxProperties'],['id_service'], ))


conn = pymysql.connect(host='localhost', user='root', passwd='',db='oas_dataset')
cur = conn.cursor();



