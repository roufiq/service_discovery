import json
import os
import jsonpath_rw_ext as jp
import pymysql
import uuid
import six
import pipes

conn = pymysql.connect(host='localhost', user='root', passwd='',db='oas')
cur = conn.cursor();

cur.execute("SELECT  id, categories FROM info_object")
query= cur.fetchall()

replace={"[":"", "]":"", "\"":"", " ":""}
def replace_all(text, dic):
    for i, j in dic.items():
        text = text.replace(i, j)
    return text

def store_category(service):
    cur.execute("INSERT INTO category_services (id, service_id,category )"
                "VALUES (%s, %s, %s)",
                (service['id'], service['service_id'], service['category']))
    cur.connection.commit()


for row in query:
    text=row[1]
    if(text):
        category = replace_all(text, replace)
        category = category.split(',')
        for cat in category:
            service = {}
            service['id'] = str(uuid.uuid4())
            service['service_id'] = row[0]
            service['category'] = cat
            store_category(service)



