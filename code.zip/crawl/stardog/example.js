{
    '/key':
    {
        'post':
        {
            'tags': ['key', 'post'],
            'description': 'Register a new ID `JWT(sub, devtoken)`\n\nv5: `JWT(sub, pk, devtoken, ...)`\n\nSee: https://github.com/skion/authentiq/wiki/JWT-Examples\n',
            'operationId': 'key_register',
            'requestBody':
            {
                '$ref': '#/components/requestBodies/AuthentiqID'
            },
            'responses':
            {
                '201':
                {
                    'description': 'Successfully registered',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'type': 'object',
                                'properties':
                                {
                                    'secret':
                                    {
                                        'type': 'string',
                                        'description': 'revoke key'
                                    },
                                    'status':
                                    {
                                        'type': 'string',
                                        'description': 'registered'
                                    }
                                }
                            }
                        }
                    }
                },
                '409':
                {
                    'description': 'Key already registered `duplicate-key`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        },
        'delete':
        {
            'tags': ['key', 'delete'],
            'description': 'Revoke an Authentiq ID using email & phone.\n\nIf called with `email` and `phone` only, a verification code \nwill be sent by email. Do a second call adding `code` to \ncomplete the revocation.\n',
            'operationId': 'key_revoke_nosecret',
            'parameters': [
            {
                'name': 'email',
                'in': 'query',
                'description': 'primary email associated to Key (ID)',
                'required': True,
                'style': 'form',
                'explode': True,
                'schema':
                {
                    'type': 'string'
                }
            },
            {
                'name': 'phone',
                'in': 'query',
                'description': 'primary phone number, international representation',
                'required': True,
                'style': 'form',
                'explode': True,
                'schema':
                {
                    'type': 'string'
                }
            },
            {
                'name': 'code',
                'in': 'query',
                'description': 'verification code sent by email',
                'required': False,
                'style': 'form',
                'explode': True,
                'schema':
                {
                    'type': 'string'
                }
            }],
            'responses':
            {
                '200':
                {
                    'description': 'Successfully deleted',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'type': 'object',
                                'properties':
                                {
                                    'status':
                                    {
                                        'type': 'string',
                                        'description': 'pending or done'
                                    }
                                }
                            }
                        }
                    }
                },
                '401':
                {
                    'description': 'Authentication error `auth-error`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                '404':
                {
                    'description': 'Unknown key `unknown-key`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                '409':
                {
                    'description': 'Confirm with code sent `confirm-first`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        }
    },
    '/key/{PK}':
    {
        'get':
        {
            'tags': ['key', 'get'],
            'description': 'Get public details of an Authentiq ID.\n',
            'operationId': 'key_retrieve',
            'parameters': [
            {
                '$ref': '#/components/parameters/PK'
            }],
            'responses':
            {
                '200':
                {
                    'description': 'Successfully retrieved',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'title': 'JWT',
                                'type': 'object',
                                'properties':
                                {
                                    'since':
                                    {
                                        'type': 'string',
                                        'format': 'date-time'
                                    },
                                    'status':
                                    {
                                        'type': 'string'
                                    },
                                    'sub':
                                    {
                                        'type': 'string',
                                        'description': 'base64safe encoded public signing key'
                                    }
                                }
                            }
                        }
                    }
                },
                '404':
                {
                    'description': 'Unknown key `unknown-key`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                '410':
                {
                    'description': 'Key is revoked (gone). `revoked-key`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        },
        'put':
        {
            'tags': ['key', 'put'],
            'description': 'Update Authentiq ID by replacing the object.\n\nv4: `JWT(sub,email,phone)` to bind email/phone hash; \n\nv5: POST issuer-signed email & phone scopes\nand PUT to update registration `JWT(sub, pk, devtoken, ...)`\n\nSee: https://github.com/skion/authentiq/wiki/JWT-Examples\n',
            'operationId': 'key_bind',
            'parameters': [
            {
                '$ref': '#/components/parameters/PK'
            }],
            'requestBody':
            {
                '$ref': '#/components/requestBodies/AuthentiqID'
            },
            'responses':
            {
                '200':
                {
                    'description': 'Successfully updated',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'type': 'object',
                                'properties':
                                {
                                    'status':
                                    {
                                        'type': 'string',
                                        'description': 'confirmed'
                                    }
                                }
                            }
                        }
                    }
                },
                '404':
                {
                    'description': 'Unknown key `unknown-key`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                '409':
                {
                    'description': 'Already bound to another key `duplicate-hash`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        },
        'post':
        {
            'tags': ['key', 'post'],
            'description': 'update properties of an Authentiq ID.\n(not operational in v4; use PUT for now)\n\nv5: POST issuer-signed email & phone scopes in\na self-signed JWT\n\nSee: https://github.com/skion/authentiq/wiki/JWT-Examples\n',
            'operationId': 'key_update',
            'parameters': [
            {
                '$ref': '#/components/parameters/PK'
            }],
            'requestBody':
            {
                '$ref': '#/components/requestBodies/AuthentiqID'
            },
            'responses':
            {
                '200':
                {
                    'description': 'Successfully updated',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'type': 'object',
                                'properties':
                                {
                                    'status':
                                    {
                                        'type': 'string',
                                        'description': 'confirmed'
                                    }
                                }
                            }
                        }
                    }
                },
                '404':
                {
                    'description': 'Unknown key `unknown-key`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        },
        'delete':
        {
            'tags': ['key', 'delete'],
            'description': 'Revoke an Identity (Key) with a revocation secret',
            'operationId': 'key_revoke',
            'parameters': [
            {
                '$ref': '#/components/parameters/PK'
            },
            {
                'name': 'secret',
                'in': 'query',
                'description': 'revokation secret',
                'required': True,
                'style': 'form',
                'explode': True,
                'schema':
                {
                    'type': 'string'
                }
            }],
            'responses':
            {
                '200':
                {
                    'description': 'Successful response',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'type': 'object',
                                'properties':
                                {
                                    'status':
                                    {
                                        'type': 'string',
                                        'description': 'done'
                                    }
                                }
                            }
                        }
                    }
                },
                '401':
                {
                    'description': 'Key not found / wrong code `auth-error`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                '404':
                {
                    'description': 'Unknown key `unknown-key`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        },
        'head':
        {
            'tags': ['key', 'head'],
            'description': 'HEAD info on Authentiq ID\n',
            'parameters': [
            {
                '$ref': '#/components/parameters/PK'
            }],
            'responses':
            {
                '200':
                {
                    'description': 'Key exists'
                },
                '404':
                {
                    'description': 'Unknown key `unknown-key`',
                    'content':
                    {
                        '*/*':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                '410':
                {
                    'description': 'Key is revoked `revoked-key`',
                    'content':
                    {
                        '*/*':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        }
    },
    '/login':
    {
        'post':
        {
            'tags': ['login', 'post'],
            'description': 'push sign-in request\nSee: https://github.com/skion/authentiq/wiki/JWT-Examples\n',
            'operationId': 'push_login_request',
            'parameters': [
            {
                'name': 'callback',
                'in': 'query',
                'description': 'URI App will connect to',
                'required': True,
                'style': 'form',
                'explode': True,
                'schema':
                {
                    'type': 'string'
                }
            }],
            'requestBody':
            {
                'description': 'Push Token.',
                'content':
                {
                    'application/jwt':
                    {
                        'schema':
                        {
                            '$ref': '#/components/schemas/PushToken'
                        }
                    }
                },
                'required': True
            },
            'responses':
            {
                '200':
                {
                    'description': 'Successful response',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'type': 'object',
                                'properties':
                                {
                                    'status':
                                    {
                                        'type': 'string',
                                        'description': 'sent'
                                    }
                                }
                            }
                        }
                    }
                },
                '401':
                {
                    'description': 'Unauthorized for this callback audience `aud-error` or JWT should be self-signed `auth-error`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        }
    },
    '/scope':
    {
        'post':
        {
            'tags': ['scope', 'post'],
            'description': 'scope verification request\nSee: https://github.com/skion/authentiq/wiki/JWT-Examples\n',
            'operationId': 'sign_request',
            'parameters': [
            {
                'name': 'test',
                'in': 'query',
                'description': 'test only mode, using test issuer',
                'required': False,
                'style': 'form',
                'explode': True,
                'schema':
                {
                    'type': 'integer'
                }
            }],
            'requestBody':
            {
                'description': 'Claims of scope',
                'content':
                {
                    'application/jwt':
                    {
                        'schema':
                        {
                            '$ref': '#/components/schemas/Claims'
                        }
                    }
                },
                'required': True
            },
            'responses':
            {
                '201':
                {
                    'description': 'Successful response',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'type': 'object',
                                'properties':
                                {
                                    'job':
                                    {
                                        'type': 'string',
                                        'description': '20-character ID'
                                    },
                                    'status':
                                    {
                                        'type': 'string',
                                        'description': 'waiting'
                                    }
                                }
                            }
                        }
                    }
                },
                '429':
                {
                    'description': 'Too Many Requests on same address / number `rate-limit`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        }
    },
    '/scope/{job}':
    {
        'get':
        {
            'tags': ['scope', 'get'],
            'description': 'get the status / current content of a verification job',
            'operationId': 'sign_retrieve',
            'parameters': [
            {
                '$ref': '#/components/parameters/JobID'
            }],
            'responses':
            {
                '200':
                {
                    'description': 'Successful response (JWT)',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'title': 'JWT',
                                'type': 'object',
                                'properties':
                                {
                                    'exp':
                                    {
                                        'type': 'integer'
                                    },
                                    'field':
                                    {
                                        'type': 'string'
                                    },
                                    'sub':
                                    {
                                        'type': 'string',
                                        'description': 'base64safe encoded public signing key'
                                    }
                                }
                            }
                        },
                        'application/jwt':
                        {
                            'schema':
                            {
                                'title': 'JWT',
                                'type': 'object',
                                'properties':
                                {
                                    'exp':
                                    {
                                        'type': 'integer'
                                    },
                                    'field':
                                    {
                                        'type': 'string'
                                    },
                                    'sub':
                                    {
                                        'type': 'string',
                                        'description': 'base64safe encoded public signing key'
                                    }
                                }
                            }
                        }
                    }
                },
                '204':
                {
                    'description': 'Confirmed, waiting for signing'
                },
                '404':
                {
                    'description': 'Job not found `unknown-job`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        },
                        'application/jwt':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        },
        'put':
        {
            'tags': ['scope', 'put'],
            'description': 'authority updates a JWT with its signature\nSee: https://github.com/skion/authentiq/wiki/JWT-Examples\n',
            'operationId': 'sign_update',
            'parameters': [
            {
                '$ref': '#/components/parameters/JobID'
            }],
            'responses':
            {
                '200':
                {
                    'description': 'Successfully updated',
                    'content':
                    {
                        'application/jwt':
                        {
                            'schema':
                            {
                                'type': 'object',
                                'properties':
                                {
                                    'jwt':
                                    {
                                        'type': 'string',
                                        'description': 'result is JWT or JSON??'
                                    },
                                    'status':
                                    {
                                        'type': 'string',
                                        'description': 'ready'
                                    }
                                }
                            }
                        }
                    }
                },
                '404':
                {
                    'description': 'Job not found `unknown-job`',
                    'content':
                    {
                        'application/jwt':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                '409':
                {
                    'description': 'Job not confirmed yet `confirm-first`',
                    'content':
                    {
                        'application/jwt':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        },
        'post':
        {
            'tags': ['scope', 'post'],
            'description': 'this is a scope confirmation',
            'operationId': 'sign_confirm',
            'parameters': [
            {
                '$ref': '#/components/parameters/JobID'
            }],
            'responses':
            {
                '202':
                {
                    'description': 'Successfully confirmed',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'type': 'object',
                                'properties':
                                {
                                    'status':
                                    {
                                        'type': 'string',
                                        'description': 'confirmed'
                                    }
                                }
                            }
                        }
                    }
                },
                '401':
                {
                    'description': 'Confirmation error `auth-error`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                '404':
                {
                    'description': 'Job not found `unknown-job`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                '405':
                {
                    'description': 'JWT POSTed to scope `not-supported`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        },
        'delete':
        {
            'tags': ['scope', 'delete'],
            'description': 'delete a verification job',
            'operationId': 'sign_delete',
            'parameters': [
            {
                '$ref': '#/components/parameters/JobID'
            }],
            'responses':
            {
                '200':
                {
                    'description': 'Successfully deleted',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                'type': 'object',
                                'properties':
                                {
                                    'status':
                                    {
                                        'type': 'string',
                                        'description': 'done'
                                    }
                                }
                            }
                        }
                    }
                },
                '404':
                {
                    'description': 'Job not found `unknown-job`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        },
        'head':
        {
            'tags': ['scope', 'head'],
            'description': 'HEAD to get the status of a verification job',
            'operationId': 'sign_retrieve_head',
            'parameters': [
            {
                '$ref': '#/components/parameters/JobID'
            }],
            'responses':
            {
                '200':
                {
                    'description': 'Confirmed and signed'
                },
                '204':
                {
                    'description': 'Confirmed, waiting for signing'
                },
                '404':
                {
                    'description': 'Job not found `unknown-job`',
                    'content':
                    {
                        'application/json':
                        {
                            'schema':
                            {
                                '$ref': '#/components/schemas/Error'
                            }
                        }
                    }
                },
                'default':
                {
                    '$ref': '#/components/responses/ErrorResponse'
                }
            }
        }
    }
}