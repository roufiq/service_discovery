import io
import stardog
import pandas as pd
import seaborn as sns

conn_details = {
  'endpoint': 'http://localhost:5820',
  'username': 'admin',
  'password': 'admin'
}

conn = stardog.Connection('sws', endpoint='http://localhost:5820', username='admin', password='admin')
a= conn.begin()
print(a)
query = """
select * {?s ?p ?o}
limit 10
"""

csv_results = conn.select(query, content_type='application/sparql-results+json')
print(csv_results)
# df = pd.read_csv(io.BytesIO(csv_results))
# df.head()
