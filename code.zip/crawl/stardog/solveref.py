import json
import jsonref
from pprint import pprint
import os
import jsonpath_rw_ext as jp
import pymysql
import uuid
import six
import pipes
import shutil


# class Object:
#     def toJSON(self):
#         return json.dumps(self, default=lambda o: o.__dict__,
#             sort_keys=True, indent=4)

def dumper(obj):
    try:
        return obj.toJSON()
    except:
        return obj.__dict__

conn = pymysql.connect(host='localhost', user='root', passwd='',db='oas')
cur = conn.cursor();

def store_info(info_object):
    # print(info_object)
    cur.execute("INSERT IGNORE INTO service (id, openapi_version, title, description, termOfService, contact_name , contact_url, contact_email,"
                " license_name, license_url, version, categories, provider_name, location_file, externalDocs_description, externalDocs_url) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s, %s, %s, %s, %s)",
                (info_object['id'], info_object['openapi_version'], info_object['title'], info_object['description'], info_object['termOfService'],
                 info_object['contact_name'], info_object['contact_url'], info_object['contact_email'], info_object['license_name'], info_object['license_url'], info_object['version'],
                 info_object['categories'], info_object['provider_name'], info_object['location_file'], info_object['externalDocs_description'], info_object['externalDocs_url'])
                )

    cur.connection.commit()

def store_tags(tag):
    cur.execute("INSERT INTO tags (id, service_id, name, description, externalDocs_description, externalDocs_url)"
                "VALUES (%s, %s, %s, %s, %s, %s )",
                (tag['id'], tag['service_id'], tag['name'], tag['description'], tag['externalDocs_description'], tag['externalDocs_url'])
                )

    cur.connection.commit()

def store_security_scheme(security_scheme):
    cur.execute("INSERT INTO security_scheme (id, service_id, security_type, description, name, scheme_in, scheme, bearerFormat, openIdConnectUrl)"
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (security_scheme['id'], security_scheme['service_id'], security_scheme['type'], security_scheme['description'], security_scheme['name'], security_scheme['in'], security_scheme['scheme'], security_scheme['bearerFormat'], security_scheme['openIdConnectUrl'],)
                )
    cur.connection.commit()

def store_oauth_flow(oauth_flow):
    cur.execute("INSERT INTO oauth_flow (id, security_scheme_id , flow_type, authorizationUrl, tokenUrl, refreshUrl)"
                "VALUES (%s, %s, %s, %s, %s, %s)",
                (oauth_flow['id'], oauth_flow['security_scheme_id'], oauth_flow['flow_type'], oauth_flow['authorizationUrl'], oauth_flow['tokenUrl'], oauth_flow['refreshUrl'])
                )
    cur.connection.commit()

def store_oauth_scopes(oauth_scope):
    cur.execute("INSERT INTO oauth_scopes(id, oauth_flow_id, scope, description)"
                "VALUES (%s, %s, %s, %s)",
                (oauth_scope['id'], oauth_scope['oauth_flow_id'], oauth_scope['scope'], oauth_scope['description']))
    cur.connection.commit()

def store_operation(operation):
    cur.execute("INSERT INTO operation (id,service_id, route, summary, description, method, operationId, tags, deprecated, externalDocs_description, externalDocs_url)"
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (operation['id'], operation['service_id'], operation['route'], operation['summary'],operation['description'],
                 operation['method'],operation['operationId'],operation['tags'],operation['deprecated'],operation['externalDocs_description'],operation['externalDocs_url']))
    cur.connection.commit()

def store_parameters(parameters):
    cur.execute("INSERT INTO parameters (id,operation_id, name, param_in, description, required, deprecated, allowEmptyValue,  style, explode, allowReserved, param_schema, example)"
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (parameters['id'], parameter['operation_id'], parameters['name'], parameters['in'], parameters['description'], parameters['required'],
                 parameters['deprecated'], parameters['allowEmptyValue'], parameter['style'], parameter['explode'], parameter['allowReserved'], parameter['schema'], parameter['example'] ))

    cur.connection.commit()

def store_schemas(schemas):
    cur.execute("""INSERT INTO schemas (id, service_id, name, properties, schema_types, schema_format, required, description, 
                allOf, items, additionalProperties, example ,title, pattern, minLength, maxLength,
                minItems, maxItems,  minimum, maximum, minProperties, maxProperties, xml, discriminator)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                (schemas['id'], schemas['service_id'], schemas['name'], schemas['properties'], schemas['type'],schemas['format'],schemas['required'], schemas['description'],
                 schemas['allOf'], schemas['items'],  schemas['additionalProperties'], schemas['example'], schemas['title'], schemas['pattern'],
                 schemas['minLength'], schemas['maxLength'], schemas['minItems'], schemas['maxItems'], schemas['minimum'], schemas['maximum'], schemas['minProperties'], schemas['minProperties'], schemas['xml'], schemas['discriminator']))

    cur.connection.commit()

def store_responses(responses):
    cur.execute("""INSERT INTO responses_object (id, operation_id, name, description, headers, content, links)
                VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                (responses['id'], responses['operation_id'] ,responses['name'], responses['description'], responses['headers'], responses['content'], responses['links']))
    # print(1)
    cur.connection.commit()

def store_requestBody(request):
    # cur.execute("""INSERT INTO requestbody (id, operation_id, description, required, ref)
    cur.execute("""INSERT INTO requestbody (id, operation_id, content, description, required)
                VALUES (%s, %s, %s, %s, %s)""",
                # (request['id'], request['operation_id'],request['description'],  request['required'], request['$ref']))
                (request['id'], request['operation_id'], request['content'],request['description'],  request['required']))
    cur.connection.commit()

def store_server(server):
    cur.execute("""INSERT INTO servers(id, service_id, url, description, server_variables)
                VALUES (%s, %s, %s, %s, %s)""",
                (server['id'], server['service_id'],server['url'], server['description'], server['server_variables']))
    cur.connection.commit()


no_file=0
method_dict={'get','post','delete','put','option','trace', 'head','patch'}
params_dict={'name','in','description', 'required', 'deprecated','allowEmptyValue','$ref', 'style', 'explode','allowReserved','schema', 'example'}
# params_schema_dict={}
responses_dict={}
schema_dict={'properties','type','format', 'required', 'description', 'type', 'allOf', 'items', 'additionalProperties', 'example','title', 'pattern',
             'minLength', 'maxLength', 'minItems', 'maxItems',  'minimum', 'maximum', 'minProperties', 'maxProperties', 'xml', 'discriminator'}

error_folder = r"D:\Download Program\error"
string = "m"

for root, dirs, files in os.walk("D:/Download Program/APIs", topdown=False):
    for name in files:
        if name == "openapi.json":
            no_file += 1
            found = os.path.join(root, name)
            print(found)
            #             load JSON file
            with open(found) as f:

                document = jsonref.load(f)

                # pprint(document)

                # INFO_OBJECT
                info_object = {}
                info_object['id'] = str(uuid.uuid4())
                info_object['openapi_version'] = jp.match1('$.openapi[*]', document)
                info_object['title'] = jp.match1('$.info.title', document)
                info_object['description'] = jp.match1('$.info.description', document)
                info_object['termOfService'] = jp.match1('$.info.termsOfService', document)
                info_object['contact_name'] = jp.match1('$.info.contact.name', document)
                info_object['contact_url'] = jp.match1('$.info.contact.url', document)
                info_object['contact_email'] = jp.match1('$.info.contact.email', document)
                info_object['license_name'] = jp.match1('$.info.license.name', document)
                info_object['license_url'] = jp.match1('$.info.license.url', document)
                info_object['version'] = jp.match1('$.info.version', document)
                info_object['location_file'] = found
                categories = document.get('info').get('x-apisguru-categories')
                if (categories is not None):
                    info_object['categories'] = json.dumps(categories)
                provider_name = document.get('info').get('x-providerName')
                if (provider_name is not None):
                    info_object['provider_name'] = provider_name
                externalDocs = document.get('externalDocs')
                if (externalDocs is not None):
                    info_object['externalDocs_description'] = externalDocs.get('description')
                    info_object['externalDocs_url'] = externalDocs.get('url')

                info_object.setdefault('openapi_version', '3.0')
                info_object.setdefault('title', 'N/A')
                info_object.setdefault('description', None)
                info_object.setdefault('termOfService', None)
                info_object.setdefault('contact_name', None)
                info_object.setdefault('contact_url', None)
                info_object.setdefault('contact_email', None)
                info_object.setdefault('license_name', None)
                info_object.setdefault('license_url', None)
                info_object.setdefault('version', '0.1')
                info_object.setdefault('categories', None)
                info_object.setdefault('provider_name', None)
                info_object.setdefault('externalDocs_description', None)
                info_object.setdefault('externalDocs_url', None)

                store_info(info_object)

                # servers

                servers_object = jp.match('$.servers[*]', document)
                # print(servers_object)
                if (servers_object is not None):
                    for s in servers_object:
                        # print(s)
                        server = s
                        server['id'] = str(uuid.uuid4())
                        server['service_id'] = info_object['id']
                        server['url'] = s.get('url')
                        server['description'] = s.get('description')
                        server.setdefault('server_variables', None)
                        if (s.get('variables') is not None):
                            server['server_variables'] = str(s.get('variables'))
                        # print(server)

                        store_server(server)

                # # todo disini harusnya semua components object diextract karena hanya bergantung pada service id utk FK
                # parameters_object={}
                # parameters_object=jp.match('$.components.parameters[*]', document)

                # check jenis key di params_object dan yang menggunakan schema object
                # param dict: {'name': 13269, 'in': 13269, 'description': 11243, 'required': 7836, 'style': 80, 'explode': 86,
                #        'schema': 13266, 'example': 144, 'x-field-config': 65, 'x-ms-enum': 255,
                #        'x-ms-parameter-location': 4578, 'x-ms-skip-url-encoding': 300, 'allowEmptyValue': 4,
                #        'x-ms-parameter-grouping': 116, 'x-ms-client-name': 99, 'x-previous-pattern': 21,
                #        'x-new-pattern': 4, 'x-comment': 2, 'x-ms-client-request-id': 12, 'x-lov': 1, 'x-enumEmoji': 1,
                #        'x-multi-segment': 2, 'examples': 18, 'x-nullable': 5, 'deprecated': 2,
                #        'x-data-threescale-name': 2, 'content': 3, 'x-enum-descriptions': 9}
                # schema dict: {'type': 13196, 'default': 594, 'enum': 1323, 'format': 377, 'example': 122, 'minimum': 121,
                #        'maximum': 65, 'items': 70, 'minLength': 444, 'maxLength': 434, 'x-ms-enum': 251,
                #        'x-ms-parameter-location': 4549, 'x-ms-skip-url-encoding': 290, 'pattern': 375, 'minItems': 17,
                #        'x-ms-parameter-grouping': 116, 'x-ms-client-name': 91, 'nullable': 9, 'x-previous-pattern': 21,
                #        'x-new-pattern': 4, 'x-comment': 2, 'x-ms-client-request-id': 12, 'oneOf': 7, '$ref': 62,
                #        'readOnly': 2, 'description': 20, 'uniqueItems': 15, 'additionalProperties': 1,
                #        'x-enum-descriptions': 9}

                # if(parameters_object):
                #     param_keys= parameters_object.pop(0)
                #     print(param_keys)
                #
                #     # print(schema_keys)
                #     for param in param_keys:
                #         # print(param)
                #         for key, value in param_keys[param].items():
                #             if key in params_dict:
                #                 params_dict.update({key: (params_dict[key] + 1)})
                #             elif key not in params_dict:
                #                 params_dict.update({key: 1})
                #         schema_keys = param_keys[param].get('schema')
                #         if(schema_keys):
                #             for s in schema_keys:
                #                 if s in params_schema_dict:
                #                     params_schema_dict.update({s: (params_schema_dict[s] + 1)})
                #                 elif s not in params_schema_dict:
                #                     params_schema_dict.update({s: 1})
                # print('param dict: ',params_dict)
                # print('schema dict: ',params_schema_dict)

                # response object
                # response_dict {'description': 267, 'content': 253, 'headers': 19, 'x-error-codes': 1, 'x-content': 1}

                schema_object = {}
                schema_object = jp.match('$.components.schemas[*]', document)
                if (schema_object):
                    schema_keys = schema_object.pop(0)
                    # print(schema_keys)
                    for i in schema_keys:
                        schemas = {}
                        schemas['id'] = str(uuid.uuid4())
                        schemas['name'] = i
                        schemas['service_id'] = info_object['id']

                        # schema_keys = responses_keys.get('schema')
                        for item in schema_dict:
                            # print(item)
                            schemas.setdefault(item, None)

                        for key, value in schema_keys[i].items():
                            # print(schema_object[i])
                            # if key in schema_dict:
                            # pakai function  json.loads()  utk column sql karena semua value akan mengandung double quote

                            # if key in ('properties', 'allOf', 'items'):
                            #     schemas.update({key: json.dumps(str(value))})
                            # else:
                            schemas.update({key: str(value)})

                        # print(schemas)
                        store_schemas(schemas)
                # print(schema_dict)

                # # RESPONSE_OBJECT
                # responses_object={}
                # responses_object=jp.match('$.components.responses[*]',document)
                # if(responses_object):
                #     responses_keys= responses.pop(0)
                #     for res in responses_keys:
                #         responses={}
                #         responses['id']= str(uuid.uuid4())
                #         responses['name']= res
                #         responses.setdefault('content', None)
                #         responses.setdefault('links', None)
                #         responses.setdefault('headers', None)
                #         for key, value in responses_keys[res].items():
                #             responses.update({key:json.dumps(value)})
                #         # print(responses)
                #         store_responses(responses)

                # SECURITY_OBJECT
                security_scheme_object = {}
                security_scheme_object = jp.match('$.components.securitySchemes[*].*', document)

                if security_scheme_object:
                    for security_scheme in security_scheme_object:
                        security_scheme['id'] = str(uuid.uuid4())
                        security_scheme['service_id'] = info_object.get('id')
                        security_scheme.setdefault('type', None)
                        security_scheme.setdefault('description', None)
                        security_scheme.setdefault('name', None)
                        security_scheme.setdefault('in', None)
                        security_scheme.setdefault('scheme', None)
                        security_scheme.setdefault('bearerFormat', None)
                        security_scheme.setdefault('openIdConnectUrl', None)
                        # print(security_scheme)
                        store_security_scheme(security_scheme)
                        # OAUTH_FLOW HERE
                        if (security_scheme.get('flows')):
                            oauth_flow = {}
                            oauth_flow = jp.match1('$.flows[*].*', security_scheme)
                            oauth_flow['id'] = str(uuid.uuid4())
                            oauth_flow['flow_type'] = list(security_scheme.get('flows').keys()).pop(0)
                            oauth_flow['security_scheme_id'] = security_scheme.get('id')

                            oauth_flow.setdefault('authorizationUrl', None)
                            oauth_flow.setdefault('tokenUrl', None)
                            oauth_flow.setdefault('refreshUrl', None)

                            # oauth_flow['flow_type']= jp.match1('$.flows[0]', security_scheme)
                            # print(oauth_flow)
                            store_oauth_flow(oauth_flow)

                            if (oauth_flow.get('scopes')):
                                # OAUTH SCOPE
                                scopes = {}
                                scopes = jp.match('$.scopes', oauth_flow)
                                # print(scopes)
                                for scope in scopes:
                                    scope['id'] = str(uuid.uuid4())
                                    scope['oauth_flow_id'] = oauth_flow['id']
                                    scope['scope'] = list(scope.keys()).pop(0)
                                    scope['description'] = list(scope.values()).pop(0)
                                    # print(scope)

                                    store_oauth_scopes(scope)

                # PATH OBJECT
                paths_object = {}
                paths_object = jp.match('$.paths', document).pop(0)

                for path in paths_object:
                    # print(paths_object[path])

                    operation = {}
                    # fixme: fix error operation method without paramss >> FIXED
                    # method_keys=list(paths_object.get(path).keys())
                    # for key, value in param_keys[param].items()

                    # mengambil method get, post, put, delete, option, patch, head, trace
                    # disini masih bisa ada tag param, handling ASAP  >> FIXED
                    if isinstance(paths_object[path], six.string_types):
                        # paths_object.pop(path)
                        continue
                    for key, value in paths_object[path].items():
                        # print("route :", path, "method:", method)
                        # exclude_list = ['$ref', 'summary', 'description', 'servers', 'parameters']
                        if key not in method_dict:
                            continue
                        operation = paths_object.get(path).get(key)
                        # print(operation)
                        operation['route'] = path
                        operation['method'] = key.upper()
                        operation['id'] = str(uuid.uuid4())
                        operation['service_id'] = info_object.get('id')

                        operation['summary'] = operation.get('summary')
                        if operation.get('summary') is None:
                            operation['summary'] = paths_object.get(path).get('summary')
                        operation['description'] = operation.get('description')
                        if operation.get('description') is None:
                            operation['description'] = paths_object.get(path).get('description')
                        operation['operationId'] = operation.get('operationId')
                        if (operation.get('externalDocs')):
                            operation['externalDocs_description'] = operation.get('externalDocs').get('description')
                            operation['externalDocs_url'] = operation.get('externalDocs').get('url')
                        operation.setdefault('externalDocs_description', None)
                        operation.setdefault('externalDocs_url', None)
                        # if (operation.get('tags')):
                        if (operation.get('tags') is not None):
                            operation['tags'] = json.dumps(operation.get('tags'))
                        operation.setdefault('tags', None)
                        operation['deprecated'] = operation.get('deprecated')
                        # operation['ref'] = paths_object.get(path).get('$ref')
                        # print(operation)

                        store_operation(operation)

                        # todo parameter memiliki relationship many to many dengan operation, reuse di OAS dg memanfaatkan schema dan $ref
                        # cara yang paling baik dengan melakukan ambil data di components.parameters baru dibuat relasi id param dan id operasi

                        parameters = {}
                        if (operation.get('parameters')):
                            parameters = operation.get('parameters')

                            # disini merupakan set parameters dari tiap operasi, dimana 1 operasi memliki >=1 parameters
                            # print("param", parameters)
                            for p in parameters:
                                parameter = {}
                                parameter = p
                                parameter['id'] = str(uuid.uuid4())
                                parameter['operation_id'] = operation['id']
                                for k in params_dict:
                                    parameter.setdefault(k, None)
                                json_schema = None
                                if (parameter['schema'] is not None):
                                    json_schema = (str(parameter['schema']))
                                json_example = None
                                if (parameter['example'] is not None):
                                    json_example = str(parameter['example'])
                                parameter['schema'] = json_schema
                                parameter['example'] = json_example

                                # try handling ref
                                # if (parameter['$ref'] is not None):
                                #     #     coba ambil datanya
                                #     text = parameter['$ref']
                                #     split = text.split("/")
                                #     # join= '$.'+'[*].'.join(str(split[i]) for i in range(1,len(split)))
                                #     json_data = document
                                #     for i in range(1, len(split)):
                                #         json_data = json_data.get(split[i])
                                #         if (json_data is None):
                                #             break
                                #     # print(join)
                                #     # get= jp.match1(join,document)
                                #     if (json_data):
                                #         # print(json_data)
                                #         for k, v in json_data.items():
                                #             # using json schema
                                #             if(k=='schema' or k=='example'):
                                #                 parameter.update({k: json.dumps(v)})
                                #                 continue
                                #             parameter.update({k: v})

                                store_parameters(parameter)

                        # todo get parameters and response, dimana parameters bisa didapatkan di path_item atau di operation, solusi?
                        # todo di docs dinyatakan A list of parameters that are applicable for this operation.
                        # If a parameter is already defined at the Path Item, the new definition will override it but can never remove it.
                        # The list MUST NOT include duplicated parameters. A unique parameter is defined by a combination of a name and location.
                        # The list can use the Reference Object to link to parameters that are defined at the OpenAPI Object's components/parameters.

                        responses = {}
                        if (operation.get('responses')):
                            responses = operation.get('responses')
                            # print(responses)
                            for r in responses:
                                # pprint(responses)
                                response = {}
                                response['id'] = str(uuid.uuid4())
                                response['operation_id'] = operation['id']
                                response['name'] = r
                                response.setdefault('description', None)
                                response.setdefault('content', None)
                                response.setdefault('links', None)
                                response.setdefault('headers', None)
                                # response.setdefault('$ref',None)
                                for key, value in responses[r].items():
                                    if key in ('headers', 'content'):
                                        response.update({key: (str((value)))})
                                    else:
                                        response.update({key: str(value)})
                                # Handling ref
                                # pprint(response)

                                store_responses(response)

                        requests = {}
                        if (operation.get('requestBody')):
                            requests = operation.get('requestBody')
                            requests['id'] = str(uuid.uuid4())
                            requests['operation_id'] = operation['id']
                            requests.setdefault('description', None)
                            requests.setdefault('content', None)
                            requests.setdefault('required', None)
                            # requests.setdefault('$ref', None)
                            # print(requests['content'])
                            if (requests['content'] is not None):
                                requests['content'] = (str(requests['content']))
                                # print(requests['content'])
                            # print(requests)

                            # if(requests['$ref'] is not None):
                            #     text = requests['$ref']
                            #     split = text.split("/")
                            #     # join= '$.'+'[*].'.join(str(split[i]) for i in range(1,len(split)))
                            #     data = document
                            #     for i in range(1, len(split)):
                            #         data = data.get(split[i])
                            #         if (data is None):
                            #             break
                            #     if (data):
                            #         # print(json_data)
                            #         for key, value in data.items():
                            #             if(key=='required'):
                            #                 if(value == True):
                            #                     requests.update({key:1})
                            #                 else:
                            #                     requests.update({key:0})
                            #                 continue
                            #             elif(key=='content'):
                            #                 requests.update({key: json.dumps(value)})
                            #                 continue
                            #             else:
                            #                 requests.update({key: value})
                            #         # print(response)
                            # print(requests)
                            store_requestBody(requests)

                # TAGS_OBJECT
                tags_object = {}
                tags_object = jp.match('$.tags[*]', document)
                # print(tags_object, "jumlah elemen ", len(tags_object))
                if tags_object:
                    for tag in tags_object:
                        # print(tag)
                        # tag['name']= jp.match1('$.name', )
                        tag['id'] = str(uuid.uuid4())
                        tag['service_id'] = info_object['id']
                        tag.setdefault('name', None)
                        tag.setdefault('description', None)
                        tag.setdefault('externalDocs_description', None)
                        tag.setdefault('externalDocs_url', None)
                        if tag.get('externalDocs'):
                            tag['externalDocs_description'] = tag['externalDocs'].get('description')
                            tag['externalDocs_url'] = tag['externalDocs'].get('url')
                        store_tags(tag)






print("total file " + str(no_file))
