import yaml
import json
import os
import commonmark


no_file=0
for root, dirs, files in os.walk("D:\Download Program/APIs/z", topdown=False):
    # pencarian setiap file yang bernama swagger format yaml dan openapi
    for name in files:
        if name == "swagger.json" :
            pass
        elif name=="openapi.yaml":
            no_file += 1


            found=os.path.join(root, name)
            print(found)
            file_swagger = open(found, 'r', encoding="utf8")
            if file_swagger.mode == 'r':
                stream = file_swagger.read()

            documents = yaml.load(stream, Loader=yaml.FullLoader)
            # json_doc= commonmark.dumpJSON(documents,sort_keys=False)
            if(name== "openapi.yaml"):
                file_json = open(os.path.join(root, 'openapi.json'), 'w+')
            # elif (name=="swagger.yaml"):
            #     file_json = open(os.path.join(root, 'swagger.json'), 'w+')
            file_json.write(json.dumps(documents, indent=4, default=str))
            # print(file_json)
            file_json.close()


print("total file "+ str(no_file))

# terdaoat 126 file error yang gagal diparsing dipindahkan ke error parsing
# sukses parsing 2913
# tomtom dan twitter error





