import json
import os
import jsonpath_rw_ext as jp
import pymysql
import uuid
import six
import pipes

conn = pymysql.connect(host='localhost', user='root', passwd='',db='oas')
cur = conn.cursor();

cur.execute("SELECT  id, service_id, tags FROM operation_object")
query= cur.fetchall()


def get_tags(service_id):
    cur.execute("SELECT * from tags_object WHERE service_id=%s", service_id)
    result= cur.fetchall()
    return result

def store_tags(operation):
    cur.execute("INSERT INTO tags_operation (id, operation_id, tag_id, tag_name)"
                "VALUES (%s, %s, %s, %s)",
                (operation['id'], operation['operation_id'], operation['tag_id'], operation['tag_name']))
    cur.connection.commit()

replace={"[":"", "]":"", "\"":""}
def replace_all(text, dic):
    for i, j in dic.items():
        text = text.replace(i, j)
    return text

for row in query:
    text=row[2]
    # print(row)
    if(text):
        service_id = row[1]
        result = get_tags(service_id)
        tags=replace_all(text, replace)
        tags=tags.strip()
        tags=tags.split(',')
        for tag in tags:
            print(tag)
            # cari di index mana
            find= [(i) for i, el in enumerate(result) if tag in el]
            if find:
                operation={}
                operation['id']= str(uuid.uuid4())
                operation['operation_id']= row[0]
                operation['tag_id']= result[find[0]][0]
                operation['tag_name']= result[find[0]][2]
                store_tags(operation)

                # print(find[0])
