import json
import os
import jsonpath_rw_ext as jp
import pymysql
import uuid
import six
import pipes
import jsonref
import ast
from pprint import pprint
conn = pymysql.connect(host='localhost', user='root', passwd='',db='oas')
cur = conn.cursor();
#
cur.execute("""SELECT  id,service_id, name, properties FROM schemas_object limit 10""")
query= cur.fetchall()

for q in query:
    if q[3] != None:
        properties = ast.literal_eval(json.loads(q[3]))
        pprint(q[0])
        print(properties)
        if properties:
            for key, values in properties.items():
                print(key)
                if values:
                    for i, v in values.items():
                        print(i)
                        print(v)

    # for key, values in properties:
    #     pprint(key)


