from bs4 import BeautifulSoup
import requests
import pandas as pd

url = "https://www.programmableweb.com/category/all/mashups?order=created&page=247"
N_mashup = {}
mashup_NO = 0

while True:
    try:
        response = requests.get(url)
        print(url)

        data = response.text
        # print(data)

        soup = BeautifulSoup(data, 'html.parser')
        # print(soup)

        interfaces = soup.find_all('tr', {'class': ['even', 'odd']})
        for interface in interfaces:
            mashup = interface.find('td', {"class": "views-field views-field-title col-md-3"})
            # print(mashup)
            mashup_title = mashup.text
            submitted = interface.find('td', {"class": "views-field views-field-created active"}).text
            submitted.replace('.', '/')
            mashup_link = mashup.find('a')
            description=None
            related_apis=None
            categories=[]
            mashup_service_url=None
            company=None
            mashup_type=None
            link = "https://www.programmableweb.com" + mashup_link.get('href')
            d_response = requests.get(link)
            d_data = d_response.text
            d_soup = BeautifulSoup(d_data, 'html.parser')
            ab_desc = d_soup.find('div', {'class': 'tabs-header_description'})
            # handling error
            description = ab_desc.find('div', {'class': 'field-item even'}).text if ab_desc else "N/A"

            # print(description)
            description = description.replace(';', ',')
            specs = d_soup.find('div', {'id': 'myTabContent'})
            apis = []
            try:
                fields = specs.find_all('div', {'class': 'field'})
                for field in fields:
                    label = field.find('label').text
                    if(label=='Related APIs'):
                        text = field.find('span')
                        apis_list= text.find_all('a')
                        for provider in apis_list:
                            api= provider.text
                            apis.append(api)
                    elif (label == 'Categories'):
                        text = field.find('span')
                        cat_list = text.find_all('a')
                        for c in cat_list:
                            cat = c.text
                            categories.append(cat)
                    elif(label=='URL'):
                        mashup_service_url=field.find('span').text
                    elif(label=='Company'):
                        company= field.find('span').text
                    elif(label=='Mashup/App Type'):
                        mashup_type=field.find('span').text

                mashup_NO+=1
                N_mashup[mashup_NO]=[mashup_title,submitted, description, apis, categories,
                                     mashup_service_url, company, mashup_type]
                print("title: ", mashup_title, "\n-----------------------")

            except AttributeError as error:
                pass
    except requests.exceptions.RequestException as e:
        pass

    url_tag = soup.find('a', {'title': 'Go to next page'})
    # condition for the the last page where we have an empty 'a' tag
    try:
        if url_tag.get('href'):
            # here we get an absolute url
            url = 'https://www.programmableweb.com' + url_tag.get('href')
            print(url)
        else:
            break
    except AttributeError as error:
        pass
    print('TOTAL NUMBER OF API: ', mashup_NO)
    API_df = pd.DataFrame.from_dict(N_mashup, orient='index', columns=['title', 'submitted', 'description','related_apis',
                                                                       'categories','mashup_url', 'company','mashup_type'])
    API_df.head()
    API_df.to_csv('C:/Users/Asus/OneDrive/Documents/Tugas Kuliah/Semester 3/Tesis/crawl/Mashup 2021  247.csv', sep=';',
                  escapechar='"')
    print('Data Added to CSV!')
