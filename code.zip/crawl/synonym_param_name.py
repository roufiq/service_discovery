import nltk
from string import digits
from nltk.corpus import wordnet
import pymysql
import re
from itertools import chain

# nltk.download('wordnet')
conn = pymysql.connect(host='localhost', user='root', passwd='', db='rapidapi')
cursor = conn.cursor();


cursor.execute("SELECT id, name FROM parameters")
def update_synonyms(id, synonyms):
    cur=conn.cursor()
    cur.execute("""
        UPDATE parameters
        SET name_clean=%s
        WHERE id=%s
    """, (synonyms, id))
    cur.connection.commit()
    print("updated")


records=cursor.fetchall()
total=0
for row in records:
    synonyms = []
    id=row[0]
    name=row[1]
    # print(name)
    # remove digits from string
    remove_digits = str.maketrans('', '', digits)
    name = name.translate(remove_digits)
    # synsets synonim
    # for syn in wordnet.synsets(name):
    #     for l in syn.lemmas():
    #         synonyms.append(l.name())

    synonyms = wordnet.synsets(name)
    lemmas = set(chain.from_iterable([word.lemma_names() for word in synonyms]))
    # print(lemmas)

    listToStr = ','.join(map(str, lemmas))
    removed= re.sub(r'\b(.+)(\s+\1\b)+', r'\1', listToStr)
    update_synonyms(id, removed)
    total += 1
print(total)