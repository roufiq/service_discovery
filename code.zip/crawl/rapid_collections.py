from gql import gql, Client, AIOHTTPTransport
from pprint import pprint
import pymysql

# configure DB
from gql.transport.exceptions import TransportError
from pymysql import Error


query_collections= gql(
    """
    query CollapsedCollections($orderByField: String, $orderDirection: OrderDirection) {
    collapsedCollections(orderByField: $orderByField, orderDirection: $orderDirection) {
        id
        title
        slugifiedKey
        weight
        thumbnail
        shortDescription
        longDescription
        apis
    }
}
    """
)
params= {"orderByField": "weight", "orderDirection": "asc"}

url="https://rapidapi.com/_gateway/graphql"
transport = AIOHTTPTransport(url=url)
client = Client(transport=transport, fetch_schema_from_transport=True)
conn = pymysql.connect(host='localhost', user='root', passwd='', db='rapidapi')
cur = conn.cursor()
cur.execute("SELECT * from collections")

# stroring collections item
def store(collection):
    cur.execute("INSERT IGNORE INTO collections (id, title, thumbnail, shortDescription, "
                "longDescription, slugifiedKey, weight) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (collection['id'],collection['title'],collection['thumbnail'],collection['shortDescription'],
                 collection['longDescription'],collection['slugifiedKey'], collection['weight']))
    cur.connection.commit()

# many to many relation apis - collection
def store_apis(collection_id, apis):
    cur.execute("INSERT IGNORE INTO collection_api (collection_id, provider_id) "
                "VALUES (%s, %s)",
                (collection_id, apis))
    cur.connection.commit()

try:
    collections = client.execute(query_collections, variable_values=params)['collapsedCollections']
    for collection in collections:
        pprint(collection['id'])
        store(collection)
        num_apis= len(collection['apis'])
        collection_id=collection['id']
        for x in range(num_apis):
            store_apis(collection_id, collection['apis'][x])
except TransportError as e:
    pprint("Error ", e)

finally:
    if (conn.open):
        conn.close()
        cur.close()
        print("MySQL connection is closed")
