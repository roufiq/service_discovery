from nltk.tokenize import word_tokenize
from string import digits
from nltk.corpus import stopwords
import re
import pymysql
import nltk
from nltk.stem import PorterStemmer

ps= PorterStemmer()
from pprint import pprint

# nltk.download('stopwords')
conn = pymysql.connect(host='localhost', user='root', passwd='', db='rapidapi')
cursor = conn.cursor();

# tokenize description from provider table
cursor.execute("SELECT id, description FROM provider")
def update_token(id, clean_desc):
    cur=conn.cursor()
    cur.execute("""
        UPDATE provider
        SET clean_desc=%s
        WHERE id=%s
    """, (clean_desc, id))
    cur.connection.commit()
    print("updated")

tokenizer= nltk.RegexpTokenizer(r"\w+")
stop_words=stopwords.words

records= cursor.fetchall()
for row in records:
    id=row[0]
    text= row[1].lower()

    # remove digits from string
    remove_digits = str.maketrans('', '', digits)
    text = text.translate(remove_digits)
    # pprint(text)
    # filter out URL
    text = re.sub(r'^https?:\/\/.*[\r\n]*', '', text, flags=re.MULTILINE)

    # tokenize= word_tokenize(text)
    # remove punctuation
    text_without_punkt= tokenizer.tokenize(text)
    # print(text_without_punkt)
    tokens_without_sw = [word for word in text_without_punkt if word not in stopwords.words()]
    # print(tokens_without_sw)
    stem = [word for word in tokens_without_sw if word not in ps.stem(word)]
    # print(stem)
    listToStr = ','.join(map(str, stem))
    update_token(id,listToStr)






