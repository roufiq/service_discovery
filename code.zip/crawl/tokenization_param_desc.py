from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import re
import pymysql
import nltk
from nltk.stem import PorterStemmer
from string import digits
ps= PorterStemmer()
from pprint import pprint

# nltk.download('stopwords')
conn = pymysql.connect(host='localhost', user='root', passwd='', db='rapidapi')
cursor = conn.cursor();

# tokenize description from provider table
cursor.execute("SELECT id, description FROM parameters")
def update_token(id, clean_desc):
    cur=conn.cursor()
    cur.execute("""
        UPDATE parameters
        SET clean_desc=%s
        WHERE id=%s
    """, (clean_desc, id))
    cur.connection.commit()
    print("updated")

tokenizer= nltk.RegexpTokenizer(r"\w+")
stop_words=stopwords.words

records= cursor.fetchall()
for row in records:
    id=row[0]
    text= row[1].lower()
    # remove digits from string
    remove_digits = str.maketrans('', '', digits)
    text = text.translate(remove_digits)
    # pprint(text)
    # filter out URL
    text= re.sub(r'[0-9]+', '', text)
    text = re.sub(r'^https?:\/\/.*[\r\n]*', '', text, flags=re.MULTILINE)

    # tokenize= word_tokenize(text)
    # print(tokenize)
    text_without_punkt= tokenizer.tokenize(text)
    # print(text_without_punkt)
    tokens_without_sw = [word for word in text_without_punkt if not word in stopwords.words()]
    # print(tokens_without_sw)
    stem = [word for word in tokens_without_sw if not word in ps.stem(word)]
    # print(stem)
    listToStr = ','.join(map(str, stem))
    update_token(id,listToStr)






