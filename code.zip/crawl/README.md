using Python 3.7
Query menggunakan GraphQL 
Package: 1. gql 2. pymsql
            