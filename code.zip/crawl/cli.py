from hydra_openapi_parser.openapi_parser import parse
import json
import click
import yaml


@click.command()
@click.argument(
    'apidoc', required=True, help="Location to input OpenAPI (YAML).", type=str
)
@click.argument(
    'hydradoc', default="", help="Location to HydraDocumentation (JSON-LD).", type=str
)
def runparser(apidoc: str, hydradoc: str):
    """
    Python Hydra OpenAPI Parser

    :param apidoc <str>     : Sets the link to the Open Api file.
                            (Supported formats - [.yaml])
    :param hydradoc <str>   : Sets the link to the HydraDoc file
                            (Supported formats - [.py, .jsonld, .yaml])
    :param parse            : Parses the OpenAPI doc into HydraDoc.

    :return                 : None.


    Raises:
        Error: If `openapidoc` is not in supported format[.yaml].

    """

    # Define the Hydra API Documentation
    # NOTE: You can use your own API Documentation and create a HydraDoc object
    # using doc_maker or you may create your own HydraDoc Documentation using
    # doc_writer [see hydra_python_core/doc_writer_sample]
    click.echo("Creating the API Documentation")

    # Getting hydradoc format
    # Currently supported formats [.jsonld, .py, .yaml]
    with open(apidoc, "r") as stream:
        doc = parse(yaml.load(stream))
    if hydradoc:
        with open(hydradoc, "w") as f:
            json.dump(doc, f)
    else:
        click.echo("Generated as hydradoc: \n{}".format(doc))


if __name__ == "__main__":
    runparser()