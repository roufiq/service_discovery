import pymysql

conn = pymysql.connect(host='localhost', user='root', passwd='', db='rapidapi')
cursor = conn.cursor();

cursor.execute("SELECT * FROM provider")
# Daftar vocabularies yang digunakan

# @prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .  >>RDF
# @prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> . >>RDFS
# @prefix schema: <http://schema.org/> . >>SDO
# @prefix xsd: <http://www.w3.org/2001/XMLSchema#> . >>XSD
# @prefix http: <http://www.w3.org/2011/http#> .
# @prefix jsonsc: <http://www.w3.org/2019/wot/json-schema#> .
# @prefix cnt: <http://www.w3.org/2011/content#> .
# @prefix dct: <http://purl.org/dc/terms> .
# @prefix : <https://www.itbsmartcampus.id/service-registry#> .

from rdflib.namespace import RDF, RDFS, XSD, SDO


