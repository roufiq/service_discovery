from selenium.webdriver.support.ui import WebDriverWait as wait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

from time import sleep


# make webdriver object
chrome_options = Options()
#chrome_options.add_argument("--disable-extensions")
#chrome_options.add_argument("--disable-gpu")
#chrome_options.add_argument("--no-sandbox") # linux only
chrome_options.add_argument("--headless")
# chrome_options.headless = True # also works
browser = webdriver.Chrome(r"C:\Users\Asus\OneDrive\Documents\Tugas Kuliah\Semester 3\Tesis\crawl\chromedriver.exe", options=chrome_options)
browser.maximize_window()
browser.execute_script('document.body.style.MozTransform = "scale(0.33)";')

# open page
browser.get("https://any-api.com")
services = wait(browser, 15).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'scrollable-content')))

while True:
    # Scroll down to last name in list
    browser.execute_script('arguments[0].scrollIntoView();', services[-1])
    try:
        # Wait for more names to be loaded
        wait(browser, 15).until(lambda driver: len(wait(driver, 15).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'scrollable-content')))) > len(services))
        # Update names list
        services = wait(browser, 15).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'scrollable-content')))
    except:
        # Break the loop in case no new names loaded after page scrolled down
        break

# Print names list
print(len(services))
print([service.text for service in  services])

# close webdriver object
browser.close()

