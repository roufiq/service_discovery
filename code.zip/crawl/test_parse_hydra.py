from hydra_openapi_parser import openapi_parser
from pprint import pprint
import yaml
import os

# doc=''
os.path.abspath(__file__)
# with open(os.path.join(sys.path[0], "samples/swagger.yaml"), 'r') as stream:
with open("samples/openapi.yaml", 'r') as stream:
    try:
        doc = yaml.load(stream)
        # pprint(doc)
    except yaml.YAMLError as exc:
        print(exc)
hydra_doc = openapi_parser.parse(doc)
# pprint(hydra_doc)

with open("samples/test3.py", "w") as f:
    f.write(openapi_parser.dump_documentation(hydra_doc))

