import click
from hydra_openapi_parser.openapi_parser import parse
import json
import yaml
import os

@click.command()
@click.argument('apidoc', default='samples/openapi.yaml')
@click.argument('hydradoc', type=str)
def hello(apidoc, hydradoc):
    os.path.abspath(__file__)
    # click.echo(f'{apidoc} is {hydradoc} years old')
    with open(apidoc, "r") as stream:
        doc = parse(yaml.load(stream))
    if hydradoc:
        with open(hydradoc, "w") as f:
            json.dump(doc, f)
    else:
        click.echo("Generated as hydradoc: \n{}".format(doc))


if __name__ == '__main__':
    hello()